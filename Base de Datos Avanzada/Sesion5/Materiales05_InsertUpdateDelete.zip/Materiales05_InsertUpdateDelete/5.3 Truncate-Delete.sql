/*SESION 05: DIFERENCIAS DELETE - TRUNCATE
INSTRUCTOR : JOSE LEON CABEL */

--CREAREMOS LA BD AGENDA
USE MASTER
GO

CREATE DATABASE AGENDA
GO
USE AGENDA
GO

-- CREAMOS LA TABLA TB_CONTACTOS
CREATE TABLE Tb_Contactos
(
IdContacto int identity (1,1),
NomContacto varchar(30),
ApeContacto varchar(30),
TelContacto varchar (10)
Primary key (IdContacto) 
)
go

-- INSERTAMOS 3 CONTACTOS
INSERT INTO Tb_Contactos 
   VALUES 
   ('JOSE','LEON','99128812'),
   ('CARMEN','MONTOYA','99188234'),
   ('LUIS','ISLA','96612891')
GO

--COMPROBAMOS
SELECT * FROM Tb_Contactos 
GO

--ELIMINANDO EL CONTACTO 3
DELETE FROM Tb_Contactos WHERE IdContacto =3
GO

--COMPROBAMOS
SELECT * FROM Tb_Contactos 
GO

-- INSERTAMOS 2 NUEVOS CONTACTOS
INSERT INTO Tb_Contactos 
   VALUES 
   ('JUAN','ALVA','997718813'),
   ('GUILLERMO','VEGA','966171223'),
   ('MONICA','DELGADO','990056221')
GO

-- COMPROBAMOS Y VEA QUE EL VALOR PARA EL IDCONTACTO 3 
-- YA NO SE GENERA...
SELECT * FROM Tb_Contactos 
GO

-- ELIMINEMOS EL CONTACTO 6
DELETE FROM Tb_Contactos WHERE IdContacto =6
GO

-- SI DESEAMOS INSERTAR 2 NUEVOS CONTACTOS, PERO 
-- DESDE EL IDCONTACTO 6 USAMOS LO SIGUIENTE CHECKIDENT ('TB_CONTACTOS', RESEED,5)
-- DONDE 5 ES EL VALOR A PARTIR DEL CUAL SE REINICIA EL CONTEO
DBCC CHECKIDENT ('TB_CONTACTOS', RESEED,5)
GO

--INSERTAMOS 2 CONTACTOS
INSERT INTO Tb_Contactos 
   VALUES 
   ('PEDRO','ARIAS','997712244'),
   ('ANA','RAEZ','966178877')
GO

-- COMPROBAMOS Y VEA QUE EL VALOR PARA EL 
-- IDCONTACTO 6 YA SE GENERA...
SELECT * FROM Tb_Contactos 
GO

-- Si empleamos TRUNCATE TABLE, eliminamos todos  
-- registros y al reinsertar automaticamente se reinicia desde 0
-- el valor de la columna Identity IdContacto, sin necesidad de 
-- emplear DBCC CHECKIDENT

TRUNCATE TABLE  TB_CONTACTOS
GO

-- Comprobamos que la tabla esta vacia
Select * from Tb_Contactos 
go

-- Insertemos 3 nuevos contactos
INSERT INTO Tb_Contactos 
   VALUES 
   ('JOSE','CORCUERA','99556612'),
   ('CARLA','RUIZ','98887734'),
   ('LUIS','SOTO','94412221')
GO
-- Comprobamos que el IdContacto se reinicia desde 0

Select * from Tb_Contactos 
go
