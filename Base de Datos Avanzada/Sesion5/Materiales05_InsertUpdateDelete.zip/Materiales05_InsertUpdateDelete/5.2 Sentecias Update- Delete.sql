/* SESION 5 : SENTENCIAS DE ACTUALIZACION UPDATE DELETE
INSTRUCTOR: JOSE LEON CABEL */

/* SENTENCIA UPDATE*/
-------------------------------------------------------------------------------------------------------
/* 1. INCREMENTE EN UN 25% EL SUELDO DEL VENDEDOR V09*/

-- Verifique el estado actual...
Select * from tb_Producto
go
--Actualizamos segun lo pedido


-- Compruebe
Select * from tb_Producto
go

/*2. ACTUALIZAR LOS DATOS NOMBRE, APELLIDO Y FECHA DE INGRESO DEL VENDEDOR
-- V02 CON LOS DATOS 'CECILIA','ZEVALLOS', Y LA FECHA ACTUAL RESPECTIVAMENTE */
-- Verificamos el estado actual..
SELECT * 
  FROM TB_VENDEDOR 
 WHERE COD_VEN ='V02'
GO
-- Actualizamos...

--Comprobamos...
SELECT * 
  FROM TB_VENDEDOR 
 WHERE COD_VEN ='V02'
GO

/* 3. INCREMENTE EN UN 10% EL PRECIO DE ABASTECIMIENTO DE LOS PRODUCTOS 
ABASTECIDOS POR LOS PROVEEDORES V009 Y V001*/
-- Hacemos una consulta previa..
Select cod_pro, pre_aba  
from Tb_Abastecimiento 
where cod_prv in ('V009','V001')
GO
--Ahora actualizamos los precios de abastecimiento de estos productos....


/* 4. SE HA DECIDIDO RENOVAR EL CONTRATO A LOS VENDEDORES CON MAS DE 4 A�OS DE ANTIGUEDAD.
LA NUEVA FECHA DE INGRESO SERA LA DE HOY*/

--Verificamos los vendedores con mas de 4 a�os de antiguedad
Select * from Tb_Vendedor 
WHERE datediff(d,fec_ing,getdate())/365 > 4
go
-- Actualizamos lo pedido


--Comprobando....
Select * from Tb_Vendedor 
WHERE datediff(d,fec_ing,getdate())/365 > 4
go


/* SENTENCIA DELETE */
-------------------------------------------------------------------------------------------------------
--PARA NO ALTERAR LA INFORMACION DE NUESTRAS TABLAS ORIGINALES, 
-- CREAREMOS COPIAS DE LAS MISMAS Y EN ELLAS APLICAREMOS EJEMPLOS DE ELIMINACION

/*  6. ELIMINE DE LA TABLA COPIA CLIENTE A AQUELLOS CLIENTES 
CON MENOS DE 2 A�OS DE ANTIGUEDAD*/
--COPIA DE LA TABLA CLIENTES
SELECT *
  INTO COPIACLIENTE
  FROM TB_CLIENTE
GO 
-- COMPROBAMOS
SELECT * FROM COPIACLIENTE
GO
-- Eliminamos los clientes pedidos de la tabla COPIACLIENTE


-- COMPROBAMOS
SELECT * FROM COPIACLIENTE
GO

/* 7. ELIMINAR AQUELLOS PROVEEDORES QUE NO SE HAYAN ATENDIDO  
 NINGUNA ORDEN DE COMPRA Y NO ABASTEZCAN DE PRODUCTO ALGUNO*/
--COPIA DE LA TABLA TB_PROVEEDOR
SELECT *
  INTO COPIAPROVEEDOR
  FROM TB_PROVEEDOR
GO 
--COMPROBAMOS
SELECT * FROM COPIAPROVEEDOR
GO

--CONSULTAMOS QUE PROVEEDORES NO HAN ATENDIDO ORDEN DE COMPRA ALGUNA
-- NI ABASTEZCAN DE PRODUCTOS

--ELIMINAMOS LOS PROVEEDORES PEDIDOS

--COMPROBAMOS





