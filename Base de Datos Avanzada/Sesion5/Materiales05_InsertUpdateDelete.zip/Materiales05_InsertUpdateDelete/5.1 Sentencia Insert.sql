/*SESION 05: SENTENCIAS DE ACTUALIZACION - SENTENCIA INSERT
INSTRUCTOR : JOSE LEON CABEL */

/*SENTENCIA INSERT:  Permite insertar un registro completo o parcialmente a la tabla
-------------------------------------------------------------------------------------------------------------------------------------------------*/

/*Ejemplo de Insercion total (se llena todo el registro)
-----------------------------------------------------------------------------------------
Agregue el siguente proveedor:
Codigo: "V207"
Razon social: "Distrbuidora ACME SCRL"
Direccion: "Jr. Las Amapolas 344"
Telefono: "4457611"
RUC: "00998812310"
Representante de Ventas : "Carla Gutierrez"
Ubigeo: "140110"
Fecha Registro :La fecha del sistema
Usuario Registro : "jleon"
Usu Ult Modificacion : Null
Fec Ult Modificaicon : Null
Est_prv: 1

*/

--INSERTAMOS EL REGISTRO COMPLETO
INSERT INTO TB_PROVEEDOR
VALUES  ('V207','Distribuidora ACME SCRL','Jr. Las Amapolas 344','4457611','00998812310',
'Carla Gutierrez','140110',Getdate(),'jleon',Null,Null,1)
GO
-- COMPROBAMOS
SELECT * FROM TB_PROVEEDOR
GO

/*Ejemplo de Insercion parcial (no se llena todo el registro) 
---------------------------------------------------------------------------------------------------
NOTA: Esto es posible si los campos que va a omitir aceptan valores nulos, de lo
contrario le genera un error.
Agregue el siguiente producto:
Codigo: 'P852' 
Descripcion : "Producto Prueba"
Precio: 25 */

--INSERTAMOS EL REGISTRO
INSERT INTO TB_PRODUCTO
            (COD_PRO,DES_PRO,PRE_PRO,IMPORTADO)
VALUES ('P852','Producto Prueba',25,1)
GO
-- COMPROBAMOS
SELECT * FROM TB_PRODUCTO
GO

-- Insertando varios registros
Insert into Tb_UnidadMedida 
values ('CAJA POR 100')
Insert into Tb_UnidadMedida 
values ('CAJA POR 200')
Insert into Tb_UnidadMedida 
values ('CAJA POR 500')
go
--Comprobemos
SELECT * FROM Tb_UnidadMedida
GO

-- Desde la version SQL 2008 se pueden insertar varios registros
-- con un solo Insert
Insert into Tb_UnidadMedida 
values ('BOLSA POR 20'),
       ('BOLSA POR 50'),
	   ('EMPAQUE POR 100')
go
--Comprobemos
SELECT * FROM Tb_UnidadMedida
GO




/*Ejemplo de Insercion copiando los registro desde otra tabla empleando Insert Into*/
-------------------------------------------------------------------------------------------------------------------------------------------
/*Ejemplo 1:
 Paso  1: Crear una tabla llamada TopVendedor con la misma estructura de la tabla Tb_Vendedor*/
CREATE TABLE TOPVENDEDOR (
	COD_VEN VARCHAR(3) PRIMARY KEY ,
	NOM_VEN VARCHAR(50) NULL,
	APE_VEN VARCHAR(50) NULL,
	SUE_VEN REAL NULL,
    FEC_ING DATETIME NULL,
	TIP_VEN VARCHAR(1) NULL )
GO


/*Paso 2 :
 Insertar a la tabla Copia_vendedor, todos los vendedores de la tabla 
Tb_Vendedor que perciban un sueldo mayor de 1500*/


/* Paso 3: Comprobamos*/
SELECT * 
FROM  TOPVENDEDOR
GO

/* Ejemplo 2:
Agregue a la tabla Tb_FacturasPago (previamente creada) las facturas
generadas incluyendo los sus numeros, fechas de facturacion y cancelacion, la razon social del cliente
 asi como los dias que se han demorado en cancelarlas*/
--Paso 1: Creamos la tabla
CREATE TABLE TB_FACTURASPAGO
(NUM_FAC CHAR(5),
 FEC_FAC SMALLDATETIME,
FEC_CAN SMALLDATETIME,
RAZ_SOC_CLI VARCHAR(50),
TIEMPO INT)
GO

--Paso 2: Luego insertamos desde Tb_Factura

   
-- Paso 3: Comprobamos
SELECT * 
FROM  TB_FACTURASPAGO
GO
 

/*Creando y llenado tablas con Select Into
--------------------------------------------------------------------- */
/*Ejemplo 1
Empleando Select Into crear la tabla  Tb_ClientesTop 
con los campos Cod_cli,raz_soc_cli,dir_cli y antiguedad, 
de aquellos clientes con mas de 10 a�os de haberse registrado.*/

--Generamos la tabla y la llenamos con los registros pedidos

--Comprobando
SELECT * 
FROM TB_CLIENTESTOP

/*Ejercicio:
En base al ejemplo anterior, genere y llene la tabla TB_OrdenesPendientes
con los numeros de orden de compra, fecha de orden, razon social de proveedor,representante
de ventas del proveedor, de aquella ordenes que aun estan pendientes de entrega (est_oco='1')*/








