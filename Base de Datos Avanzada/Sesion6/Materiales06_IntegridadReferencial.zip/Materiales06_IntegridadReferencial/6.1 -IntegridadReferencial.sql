/*
Sesion 06 : 
TEMA : TIPOS DE INTEGRIDAD REFERENCIAL
INSTRUCTOR : JOSE LEON CABEL 
 */
--PASO 1: PREPARANDO EL TERRENO....
USE master
go
if Exists (select * from sysdatabases where name = 'GestionPersonal')
   DROP DATABASE GestionPersonal
GO
create DATABASE GestionPersonal
go
USE GestionPersonal
go

CREATE TABLE Departamento (
	codDepartamento INT NOT NULL PRIMARY KEY,
	nomDepartamento NVARCHAR(50) NOT NULL )
GO
CREATE TABLE Empleado (
	codEmpleado		INT identity (1,1) NOT NULL PRIMARY KEY,
	nomEmpleado		NVARCHAR(50) NOT NULL,
	apeEmpleado		NVARCHAR(50) NOT NULL,
	fecNacEmpleado DATETIME NULL,
	fecIngEmpleado	DATETIME NULL,
	DniEmpleado 	NCHAR(8),
	emailEmpleado NVARCHAR(30), 
    SueEmpleado Money,
	codDepartamento INT   NULL )
GO
--Crearemos un Constraint default para el codDepartamento con valor 1
-- en la tabla Empleado
ALTER TABLE Empleado
       ADD  CONSTRAINT Def_CodDepartamento DEFAULT 1 FOR codDepartamento
	GO

--PASO 2: INTEGRIDAD DE TIPO CANCEL
-- Creamos la FK de Empleado a Departamento. La integridad por defecto es
-- de tipo Cancel
Alter table Empleado
  add constraint FK_Empleado_Departamento
  foreign key (CodDepartamento)
  references Departamento (CodDepartamento)
  go
-- Agregamos 3 departamentos
INSERT INTO Departamento 
          VALUES ( 1,'Servicios Generales'),
				 ( 2,'Finanzas'),
				 ( 3, 'Sistemas'),
				 ( 4, 'RRHH')
GO
-- Comprobamos
SELECT * FROM Departamento
go

-- Agregamos 4 empleados, respetando la integridad referencial
INSERT INTO EMPLEADO 
	VALUES ( 'Jose', 'Leon','19660226','20150320','08863451','pjleon@yahoo.com',2900,3),
	       ( 'Carmen', 'Montoya','19660323','20180523','08863422','cmontoya@gmail.com',3000,2),
	       ( 'Eduardo', 'Cruzado','19800726',NULL,'02363455','ecruzado@outlook.com',5000,3),
		    ( 'Luis', 'Zevallos','19820318','20180724','08863451','zevallosl@live.com',3000,4),
	       ( 'Erwin', 'Zanabria','19800622','20180125','02363499','ezanabria@hotmail.com',5000,4)
go
-- Comprobamos
SELECT * FROM Empleado
go

-- Como la FK creada es de tipo Cancel (por defecto) no podemos eliminar ni actualizar el id de 
-- del departamento 2 porque esta referenciado en la tabla Empleado. Comprobemos:
Update Departamento set codDepartamento =6 
       where codDepartamento =2
go

Delete from Departamento where codDepartamento = 2
go

-- PASO 2: INTEGRIDAD REFERENCIAL EN CASCADA

-- Implementaremos ahora una FK de tipo Cascade. Esto permitira actualizar o 
-- eliminar un departamento, teniendo un efecto cascada sobre los registros
-- de la tabla Empleado referenciados al departamento actualizado o eliminado

-- Primero eliminamos la FK de tipo Cancel
Alter table Empleado
    drop constraint FK_Empleado_Departamento
go

-- Ahora recreamos la FK , pero de tipo Cascade
Alter table Empleado
  add constraint FK_Empleado_Departamento
  foreign key (CodDepartamento)
  references Departamento (CodDepartamento)
  ON UPDATE CASCADE ON DELETE CASCADE
GO
-- Al actualizar el codDepartamento 2 al valor 6
update Departamento set codDepartamento= 6
  where codDepartamento =2
  go

-- Veremos que todos los registros de empleado que referenciaban 
-- al codDepartamento 2 ahora tienen como codDepartamento el valor 6.
-- Comprobemos:
SELECT * FROM Empleado
go

-- Si ahora eliminamos el departamento con CodDepartamento 6 se eliminaran 
-- de la tabla Empleado todos los registros que tengan como CodDepartamento el valor 6
-- es decir, elimina en cascada. Comprobemos:
Delete from Departamento where codDepartamento=6
go
-- Comprobando el efecto cascada en la tabla Empleado
 SELECT * FROM Empleado
go

-- PASO 3: INTEGRIDAD REFERENCIAL TIPO SET NULL

-- Cambiaremos el tipo de integridad referencial ahora al tipo Null.
-- Primero eliminamos la FK actjual (de tipo Cascade)
Alter table Empleado
    drop constraint FK_Empleado_Departamento
go

-- Ahora recreamos la FK , pero de tipo Set Null
Alter table Empleado
  add constraint FK_Empleado_Departamento
  foreign key (CodDepartamento)
  references Departamento (CodDepartamento)
  ON UPDATE SET NULL ON DELETE SET NULL
GO

-- Al actualizar el codDepartamento 3 al valor 7....
update Departamento set codDepartamento= 7
  where codDepartamento =3
  go

-- Ahora  todos los registros de empleado que referenciaban 
-- al codDepartamento 3 ahora tienen como codDepartamento un estado Null.
-- Lo mismo hubiera pasado si eliminabamos el Departamento con codDepartamento 3
-- Comprobemos:
SELECT * FROM Empleado
go

-- PASO 4: INTEGRIDAD DE TIPO SET DEFAULT
-- Cambiaremos el tipo de integridad referencial ahora al tipo Default.
-- Primero eliminamos la FK actual (de tipo Null)
Alter table Empleado
    drop constraint FK_Empleado_Departamento
go

-- Ahora recreamos la FK , pero de tipo Set Default
Alter table Empleado
  add constraint FK_Empleado_Departamento
  foreign key (CodDepartamento)
  references Departamento (CodDepartamento)
  ON UPDATE SET DEFAULT ON DELETE SET DEFAULT
GO

-- Si eliminamos el departamento con codDepartamento 4....
Delete from Departamento where codDepartamento=4
go

-- Todos los empleados que referenciaban a ese departamento tendran
-- como codDepartamento el valor 1, que es el valor por defecto
-- Comprobemos:
Select * from Empleado
go
