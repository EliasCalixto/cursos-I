/* SESION 3: CONSULTAS MULTITABLA
INSTRUCTOR : JOSE LEON CABEL*/

/* CONSULTAS MULTITABLA*/
--------------------------

/*1 .Mostrar los razon social, direccion, telefono y el Id de ubigeo del cliente y asi como el 
departamento, provincia y distrito donde esta ubicado*/

/* Solucion con  Where  */
SELECT Raz_soc_cli, Dir_cli, Tel_cli, C.Id_ubigeo, Departamento, Provincia, Distrito
FROM Tb_Cliente C ,Tb_Ubigeo U 
WHERE U.Id_Ubigeo  = C.Id_Ubigeo
GO

/* Solucion  con Inner Join (MAS EFICIENTE):  */
SELECT Raz_soc_cli, Dir_cli, Tel_cli, C.Id_ubigeo, Departamento, Provincia, Distrito
FROM Tb_Cliente C  INNER JOIN Tb_Ubigeo U ON U.Id_Ubigeo  = C.Id_Ubigeo

GO


/* 2. Seleccione el numero de factura, fecha de facturacion, fecha de cancelacion asi como el codigo 
, RUC, direccion y telefono  del cliente que genero la factura */

Select F.num_fac,F.fec_fac,F.fec_can , F.cod_cli , C.ruc_cli, C.dir_cli,C.tel_cli
from tb_Factura F inner join tb_cliente C on C.cod_cli =F.cod_cli 
go


/* 3. Seleccione el numero de factura, codigo de cliente y estado de factura,
asi como el total facturado en  cada factura*/
SELECT F.Num_fac, F.Cod_cli, F.Est_fac, 
 SUM(D.Can_ven * D.Pre_ven) AS TotalFacturado
FROM Tb_Factura F INNER JOIN Tb_Detalle_Factura D
ON F.Num_fac = D.Num_fac
GROUP BY F.Num_fac, F.Cod_cli, F.Est_fac
GO

/* 4. Seleccione el numero de factura, fecha de facturacion, fecha de cancelacion asi como el codigo 
, su RUC, direccion y telefono  del cliente que hizo la compra ademas del codigo, nombre y apellido
del vendedor que genero la factura */

Select F.num_fac,F.fec_fac,F.fec_can, C.Cod_cli,C.Ruc_cli, C.dir_cli,C.Tel_cli ,
       V.Cod_ven,V.Nom_ven, V.Ape_ven
from Tb_Factura F inner join Tb_Cliente C on F.cod_cli=C.cod_cli
     inner join Tb_Vendedor V on F.cod_ven = V.Cod_ven 
go

/* 5 . Seleccione los numeros de orden de compra, las fechas de orden y atencion de las mismas, asi como la razon social
del proveedor a la que fue dirigida, su direccion y el nombre del departamento, provincia y distrito donde se ubica */



/* 6. Seleccione las descripciones , la cantidad vendida, precio de venta y subtotal (cantidad vendida por precio de venta)
de los productos que se han comercializado en la factura FA009*/


/* 7. Seleccione la razon social , direccion,telefono, representante de ventas,  precio de abastecimiento 
ademas de la ubicacion geografica ( nombres de departamento , provincia y distrito)
de todos los proveedores que abastecen el producto P002*/



/* OPERADOR LEFT OUTER JOIN:
Une 2 tablas, incluyendo a todos los registros del operando (tabla) a  la izquierda del 
operador LEFT OUTER JOIN tengan o no correspondencia con registros del operando (tabla)
situada a la derecha del operador*/

/*8 Seleccione el codigo y razon social de clientes, asi como el nombre del departamento, provincia
y distrito donde se ubica incluyendo a los registros de ubigeo donde no hay clientes*/



-- En base a la consulta anterior mostremos ahora solo los registros donde no existen clientes




/* OPERADOR RIGHT OUTER JOIN:
Une 2 tablas, incluyendo a todos los registros de la tabla de la derecha
tengan o no correspondencia con registros de la tabla de la izquierda*/

/*9 Desarrolle la consulta del ejercicio 8 pero ahora con Right Outer Join*/


-- Mostremos ahora solo los registros donde no existen clientes


/* 10.  Seleccione aquellos vendedores activos  (nombre, apellidos y sueldo) que no 
      hayan realizado ninguna venta (es decir, no han generado factura alguna) */

-- Con Left outer....


-- Con Right outer...



/* 11. Seleccione la razon social,ruc, telefono y direccion, asi como
 departamento, provincia y distrito donde se ubican de clientes que no han 
 generado factura alguna*/

--Con Left outer


--Con Right outer 



/*12.  Cuantos clientes no han generado facturas */


/* 13 .Seleccione los nombres de departamento y la cantidad de clientes ubicados en cada uno de ellos.
Ordenar por cantidad de clientes en orden descendente*/


/* 14 En base al ejercicio 13 modifica la consulta para que se incluya a los departamentos 
que no tienen clientes registrados */


/* MANEJANDO RECURSIVIDAD: CONSULTAS AUTOJOIN
-----------------------------------------------
Se puede establecer una relacion recursiva, es decir una tabla relacionada asi misma.
En el caso de la tabla Tb_Vendedor hay una relacion recursiva dado que el codigo de supervisor de un vendedor
es el codigo de otro vendedor (un vendedor es supervisado por uno o ningun vendedor y un vendedor supervisa
a ninguno, uno o varios proveedores). Veamos como a partir de esta relacion se pueden hacer consultas recursiva :*/

/*15 Seleccione ahora los nombres y apellidos de los vendedores con el nombre y apellido 
de cada uno de sus jefes*/

 

/* 16. Seleccione  los  nombres y apellidos de vendedores  supervisores  y la cantidad de vendedores que supervisa
cada uno de ellos */




/* MULTIPLES COMBINACIONES: CROSS JOIN */

-- 17.  Seleccione todas las combinaciones posibles de clientes con proveedores
-- mostrando solo el codigo y razon social en ambos casos


-- 18. Seleccione todas las combinaciones posibles de categorias con productos,
-- mostrando descripciones de categorias y productos


/* UNION DE RESULTADOS
El operador UNION puede unir resultados tablas ( o resultados de Select que obviamente son tablas)
con la condicion que estas tablas o resultados tengan las mismas cabeceras*/

-- 19. Seleccione los codigos de productos, descripcion y precio de aquellos productos
-- con stock actual mayor al stock minimo y  con un precio entre 10 y 50 
-- en union con los productos con un precio entre 60 y 100 que sean nacionales



-- 20. Seleccione los codigos, razon social y fecha de registros de clientes
-- registrados en el primer semestre del 2019 en union con los clientes
-- del ubigeo 140101, 140116 y 140118. Ordene el resultado por codigo de cliente




/* FUNCION CONDICIONAL CASE
Esta funcion se emplea para calcular un valor dependiendo de una condicion que involucre
a una o mas columnas de la tabla*/

--21. Muestre el codigo, apellido y nombre  (concatenados)  y la descripcion literal de su tipo, si 
-- se sabe que el tip_ven 1 es Supervisor y el tip_ven 2 es ejecutivo y ordenar por apellidos y nombres



-- 22. Seleccione el codigo , razon social , ruc y descripcion litearal del estado del cliente
-- si sabe que el est_cli 1 es Activo y el est_cli 2 es Inactivo.

-- 23. Seleccione el codigo  y descripcion de productos, asi como una observacion que dependiendo 
-- de la siguiente regla de negocio muestre lo siguiente :
-- Si el stock actual es menor o igual que el stock minimo se debera mostrar ABASTECERSE URGENTE
-- Si el stock actual es mayor por 500 o menos unidades se debera mostrar TOME SUS PRECAUCIONES
-- En otro caso mostrar STOCK ACTUAL SIN PROBLEMAS

--FORMA 1:

--FORMA 2:


/* 24. Seleccione el numero de OC, fecha de OC , fecha de atencion, codigo del proveedor, razon social del proveedor,
direccion del proveedor, departamento, provincia y distrito del proveedor y una descripcion literal del estado 
de cada orden de compra con la siguiente regla : 
est_oco 1 = Pendiente, est_oco 2 = Atendida ,est_oco 3 = Rechazada)*/ 



/*25. Seleccione el numero de factura, fechas de factura y cancelacion , codigo del cliente, razon social del cliente, ruc del cliente
monto de la factura , codigo del vendedor , apellido del vendedor, nombre del vendedor y el estado literal
dependiendo de el campo est_fac, con la siguiente regla : 
est_fac 1 = Pendiente, est_fac 2 = Cancelada ,est_fac 3 = Anulada)*/

