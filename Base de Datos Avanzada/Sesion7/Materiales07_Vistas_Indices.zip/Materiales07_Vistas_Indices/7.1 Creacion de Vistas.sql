/* Sesion 07  : CREACION DE VISTAS
INSTRUCTOR : JOSE LEON CABEL*/

/*ACTIVAMOS LA BD VentasLeon*/
USE VentasLeon
go

/* EJEMPLO 1:
Crear un vista denominada vw_VistaClientes donde se incluya el codigo
razon social, RUC, direccion , telefono, contacto , el campo est_cli , el campo Estado
( 'Activo' si el est_cli= 1 o 'Inactivo' si es = 0) , fecha de registro, antiguedad 
el campo tipo ('Con opcion a Credito' si el tip_cli =1,'Sin opcion a credito' si el tip_cli=2),
nombre de departamento, nombre de provincia  , nombre de distrito ,
el usuario de registro, el usuario de ult. modificacion 
de todos los clientes */


/* Prueba de la vista con codigo , ruc, direccion, departamento, provincia y distrito de clientes 
donde el nombre del distrito donde se ubica empiece con 'San' en el departamento de Lima
ordenados por RUC*/


/* EJEMPLO 2:
Modificar la vista vw_VistaClientes agregando el Id de Ubigeo y
la fecha de ultima actualizacion */

/* Prueba de la vista con codigo, razon social, Id_ubigeo , departamento, provincia , distrito 
y fecha de ultima modificacion de clientes cuyo numero de telefono empiece con 445*/


/*EJEMPLO 3:
 Crear una vista denominada vw_VistaFacturas donde se incluya el numero de factura,
las fechas de facturacion y cancelacion, el codigo del cliente que genero la factura, 
su razon social, RUC, telefono,departamento, provincia y distrito de ubicacion, 
asi como el total de cada factura, el campo est_fac, 
el estado en forma LITERAL de las facturas (1 --> Pendiente, 2--> Cancelada y 
3--> Anulada) , como tambien el codigo , nombre y  apellido del vendedor que hizo la venta en cada factura */



/* Prueba con todos los datos de facturas con un total facturado mayor a 1000 soles y que tengan
el estado 'Pendiente' */



/* EJEMPLO 4
Encriptar la vista de la pregunta anterior*/

/* EJEMPLO 5 :
Crear una vista denominada vw_VistaDetalleFact que incluya el numero de facturas
el codigo y descripcion del producto del detalle de factura, asi como la cantidad
vendida , el precio de venta y el subtotal (cantidad * precio ) */

/* Prueba*/

/*EJEMPLO 6:
En base al ejemplo 4 elabore una vista encriptada denominiada vw_VistaOrdenes 
con la informacion del numero de orden de compra, fechas de generacion y atencion,
el codigo y razon social del proveedor a la que fue dirigida , asi como la direccion
telefono y ubigeo concantenado (departamento-provincia-distrito) del proveedor, 
ademas de  su estados de forma LITERAL, dependiendo del campo est_oco
(1-->Pendiente, 2-->Atendida , 3-->Rechazada )*/


 /* Prueba*/
Select num_oco,fec_oco,raz_soc_prv 
from vw_VistaOrdenes
where estado='Atendida'
GO
/* EJEMPLO 7:
Elabore una vista denominada vw_VistaProductos donde aparezcan 
el codigo, descripcion , precio, stock actual, stock minimo, el Id UM, la descripcion
de la UM, el Id Categoria , la descripcion de la categoria, el campo importado 
y una descripcion de origen ( si el campo Importado es 1 que muestre 'Importado' , 
si es 0 que muestre 'Nacional') , el campo est_pro y su decripcion literal
 (1--> Activo, 0-->Inactivo), ademas de la fecha de registro y usuario de registro 
*/

/* Prueba*/



/*EJEMPLO 8 : EL OPERADOR PIVOT
SQL Server 2005-2008 incorpora el operador PIVOT que es m�s f�cil de entender e 
implementar que los operadores ROLLUP y CUBE versiones anteriores de SQL Server. 
Por ejemplo, con el operador PIVOT podemos rotar filas y mostrarlas como columnas 
para obtener una vista diferente de los datos. El resultado de PIVOT es una tabla
 de doble entrada. */





