/* SESION 4 : SUBCONSULTAS
INSTRUCTOR : JOSE LEON CABEL*/

/* 1. Selecci�ne la razom cpcial y ruc de clientes con una antiguedad mayor a la antiguedad promedio . */


/*2. Seleccione los nombres y apellidos de vendedores que no ha generado facturas*/

/*3.  Seleccione cuantas facturas han sido generadas por los vendedores  supervisados por el  vendedor V02*/


/* 4. Seleccione los nombres de productos que se han comercializado en la factura FA002*/


/* 5. Muestre la descripci�n y precio de productos cuyo precio supera 
en 50 soles o mas al precio promedio */


/*6. Muestre el codigo de cliente y una condicion ("Deudor" o "Sin Deudas")
dependiendo si tiene o no facturas pendientes*/



